# Buscaminas
Buscaminas con tamaño ajustable.

# Page's Link
https://edgarin64.github.io/buscaminas/

# Screenshot
![Buscaminas](https://github.com/EdgarIn64/buscaminas/assets/79272954/e75ab1a0-fff7-4868-8822-5273edc70437)
